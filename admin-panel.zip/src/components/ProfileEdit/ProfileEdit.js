import React from "react";
import {
  HStack,
  Text,
  Stack,
  BreadcrumbLink,
  BreadcrumbItem,
  Breadcrumb,
  SimpleGrid,
  Box,
  Image,
  ListItem,
  Flex,
  Select,
  UnorderedList,
  Table,
  Tr,
  Input,
  Td,
  Link,
  Checkbox,
  Switch,
  GridItem,
  Grid,
  FormControl,
  Button,
  background,
} from "@chakra-ui/react";
import {
  InfoIcon,
  EmailIcon,
  PhoneIcon,
  InfoOutlineIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  CloseIcon,
  EditIcon,
} from "@chakra-ui/icons";
import Sidebar from "../../components/Sidebar/Sidebar";
import Header from "../../components/Header/Header";
function ProfileEdit() {
  return (
    <div>
      <Grid gridTemplateColumns={"300px 1fr"}>
        <GridItem>
          <Sidebar />
        </GridItem>
        <GridItem bgColor="gray.50">
          <Header />

          <Box px={9}>
            <HStack
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              mb={6}
            >
              <Stack spacing={0}>
                <Text fontSize="18px" color="gray.800" fontWeight={500}>
                  Account Settings
                </Text>

                <Breadcrumb
                  separator="-"
                  fontSize="13px"
                  color="gray.400"
                  fontWeight={500}
                >
                  <BreadcrumbItem>
                    <BreadcrumbLink href="#">Home</BreadcrumbLink>
                  </BreadcrumbItem>
                  <BreadcrumbItem>
                    <BreadcrumbLink href="#">Account</BreadcrumbLink>
                  </BreadcrumbItem>
                </Breadcrumb>
              </Stack>
            </HStack>
            <SimpleGrid>
              <Box
                mb={6}
                bg="white"
                boxShadow="md"
                borderRadius="10"
                p={5}
                position="relative"
                display={"flex"}
              >
                <HStack position={"relative"}>
                  <Image
                    src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-1.jpg"
                    w={160}
                    h={160}
                    borderRadius={5}
                  />
                  <Box
                    bg="green.300"
                    right={"-10px"}
                    bottom={6}
                    p={1.5}
                    position={"absolute"}
                    color="white"
                    borderRadius={"100%"}
                    border={"3px solid white"}
                  ></Box>
                </HStack>
                <Box px={"4"}>
                  <Text fontSize="20px" mb={"1"} fontWeight={500}>
                    Max Smith
                  </Text>
                  <UnorderedList
                    listStyleType={"none"}
                    display={"flex"}
                    fontSize={"14px"}
                    color={"gray.400"}
                    ms={"0"}
                    mb={"8"}
                  >
                    <ListItem me={3}>
                      <InfoIcon w={4} h={4} /> Developer
                    </ListItem>
                    <ListItem me={3}>
                      {" "}
                      <PhoneIcon w={3} h={3} />
                      +91 4444 4444
                    </ListItem>
                    <ListItem me={3}>
                      {" "}
                      <EmailIcon w={4} h={4} me={1} />
                      max@kt.com
                    </ListItem>
                  </UnorderedList>
                  <HStack>
                    <Box
                      border={"1px dashed"}
                      borderColor={"gray.300"}
                      display={"inline-block"}
                      px={"4"}
                      py={"2"}
                    >
                      <Text fontSize="20px" color="gray.800" fontWeight={500}>
                        <ArrowUpIcon w={"5"} h={"5"} color={"green.400"} />
                        $4,500
                      </Text>
                      <Text fontSize="14px" color="gray.400" fontWeight={500}>
                        Earnings
                      </Text>
                    </Box>
                    <Box
                      border={"1px dashed"}
                      borderColor={"gray.300"}
                      display={"inline-block"}
                      px={"8"}
                      py={"2"}
                    >
                      <Text fontSize="20px" color="gray.800" fontWeight={500}>
                        <ArrowDownIcon w={"5"} h={"5"} color={"red.400"} />
                        75
                      </Text>
                      <Text fontSize="14px" color="gray.400" fontWeight={500}>
                        Projects
                      </Text>
                    </Box>
                    <Box
                      border={"1px dashed"}
                      borderColor={"gray.300"}
                      display={"inline-block"}
                      px={"4"}
                      py={"2"}
                    >
                      <Text fontSize="20px" color="gray.800" fontWeight={500}>
                        <ArrowUpIcon w={"5"} h={"5"} color={"green.400"} />
                        %60
                      </Text>
                      <Text fontSize="14px" color="gray.400" fontWeight={500}>
                        Success Rate
                      </Text>
                    </Box>
                  </HStack>
                </Box>
              </Box>
            </SimpleGrid>
            <SimpleGrid>
              <Box
                mb={6}
                bg="white"
                boxShadow="md"
                borderRadius="10"
                position="relative"
              >
                <Box
                  display={"flex"}
                  justifyContent="space-between"
                  borderBottom={"1px solid"}
                  borderColor={"gray.300"}
                  p={5}
                >
                  <Text fontSize="20px" color="gray.800" fontWeight={500}>
                    Profile Details
                  </Text>
                </Box>
                <SimpleGrid
                  columns={1}
                  spacing={3}
                  px={6}
                  py={12}
                  borderBottom={"1px solid"}
                  borderColor={"gray.300"}
                >
                  <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                    <Text color="gray.400" w={"30%"}>
                      Avatar
                    </Text>
                    <Box position={"relative"}>
                      <Image
                        src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-1.jpg"
                        maxW={125}
                        borderRadius={5}
                        border="2px solid"
                        borderColor={"white"}
                        boxShadow="lg"
                      />
                      <Link
                        position={"absolute"}
                        right={"50px"}
                        top={"-8px"}
                        w={8}
                        h={8}
                        display="flex"
                        alignItems={"center"}
                        justifyContent="center"
                        boxShadow="lg"
                        bg={"white"}
                        borderRadius="100%"
                        color={"gray.400"} _hover={{color:"white", background:"green.400"}}
                      >
                        <EditIcon/>
                      </Link>
                      <Link
                        position={"absolute"}
                        right={"50px"}
                        bottom="40px"
                        w={8}
                        h={8}
                        display="flex"
                        alignItems={"center"}
                        justifyContent="center"
                        boxShadow="lg"
                        bg={"white"}
                        borderRadius="100%"
                        color={"gray.400"} _hover={{color:"white", background:"green.400"}}
                      >
                        <CloseIcon fontSize={9}/>
                      </Link>
                      <Text
                        fontSize={"13px"}
                        color={"gray.400"}
                        fontWeight={400}
                        my={4}
                      >
                        Allowed file types: png, jpg, jpeg.
                      </Text>
                    </Box>
                  </HStack>
                  <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                    <Text color="gray.400" w={"30%"}>
                      Full Name
                    </Text>
                    <SimpleGrid columns={2} w={"70%"} gap={5}>
                      <Box>
                        <FormControl isRequired>
                          <Input
                            placeholder="First Name"
                            bg="gray.100"
                            border={0} _focus={{boxShadow:"none"}}
                          />
                        </FormControl>
                      </Box>
                      <Box>
                        <FormControl isRequired>
                          <Input
                            placeholder="Last Name"
                            bg="gray.100"
                            border={0} _focus={{boxShadow:"none"}}
                          />
                        </FormControl>
                      </Box>
                    </SimpleGrid>
                  </HStack>
                  <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                    <Text color="gray.400" w={"30%"}>
                      Company
                    </Text>
                    <SimpleGrid w={"70%"}>
                      <Box>
                        <FormControl isRequired>
                          <Input
                            placeholder="Company Name"
                            bg="gray.100"
                            border={0} _focus={{boxShadow:"none"}}
                          />
                        </FormControl>
                      </Box>
                    </SimpleGrid>
                  </HStack>
                  <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                    <Text color="gray.400" w={"30%"}>
                      Phone Number{" "}
                      <InfoOutlineIcon
                        w={4}
                        h={4}
                        bg={"gray.500"}
                        borderRadius={"100%"}
                        color="gray.200"
                      />
                    </Text>
                    <SimpleGrid w={"70%"}>
                      <Box>
                        <FormControl isRequired>
                          <Input
                            placeholder="Phone Number"
                            bg="gray.100"
                            border={0} _focus={{boxShadow:"none"}}
                          />
                        </FormControl>
                      </Box>
                    </SimpleGrid>
                  </HStack>
                  <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                    <Text color="gray.400" w={"30%"}>
                      Company Webite
                    </Text>
                    <SimpleGrid w={"70%"}>
                      <Box>
                        <FormControl isRequired>
                          <Input
                            placeholder="Company Website"
                            bg="gray.100"
                            border={0} _focus={{boxShadow:"none"}}
                          />
                        </FormControl>
                      </Box>
                    </SimpleGrid>
                  </HStack>
                  <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                    <Text color="gray.400" w={"30%"}>
                      Country{" "}
                      <InfoOutlineIcon
                        w={4}
                        h={4}
                        bg={"gray.500"}
                        borderRadius={"100%"}
                        color="gray.200"
                      />
                    </Text>
                    <Select
                      placeholder="Select Country.."
                      w={"70%"}
                      bg="gray.100"
                      border={0}
                      color={"gray.500"} _focus={{boxShadow:"none"}}
                    >
                      <option value="option1">Option 1</option>
                      <option value="option2">Option 2</option>
                      <option value="option3">Option 3</option>
                    </Select>
                  </HStack>
                  <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                    <Text color="gray.400" w={"30%"}>
                      Language{" "}
                    </Text>
                    <Box w={"70%"}>
                    <Select
                      placeholder="Select a Language.."
                      w={"100%"}
                      bg="gray.100"
                      border={0}
                      color={"gray.500"} _focus={{boxShadow:"none"}}
                    >
                      <option value="option1">Option 1</option>
                      <option value="option2">Option 2</option>
                      <option value="option3">Option 3</option>
                    </Select>
                    <Text fontSize={13} color={"gray.300"} display="block">
                      Select a Language... Please select a preferred language,
                      including date, time, and number formatting.
                    </Text></Box>
                  </HStack>
                  <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                    <Text color="gray.400" w={"30%"}>
                      Time Zone
                    </Text>
                    <Select
                      placeholder="Select a timezone.."
                      w={"70%"}
                      bg="gray.100"
                      border={0}
                      color={"gray.500"} _focus={{boxShadow:"none"}}
                    >
                      <option value="option1">Option 1</option>
                      <option value="option2">Option 2</option>
                      <option value="option3">Option 3</option>
                    </Select>
                  </HStack>
                  <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                    <Text color="gray.400" w={"30%"}>
                      Currency
                    </Text>
                    <Select
                      placeholder="Select a Currency.."
                      w={"70%"}
                      bg="gray.100"
                      border={0}
                      color={"gray.500"} _focus={{boxShadow:"none"}}
                    >
                      <option value="option1">Option 1</option>
                      <option value="option2">Option 2</option>
                      <option value="option3">Option 3</option>
                    </Select>
                  </HStack>
                  <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                    <Text color="gray.400" w={"30%"}>
                      Communication{" "}
                    </Text>
                    <Stack spacing={5} direction="row">
                      <Checkbox colorScheme='green'  defaultChecked _focus={{boxShadow:"none"}}>Email</Checkbox>
                      <Checkbox colorScheme='green'  defaultChecked _focus={{boxShadow:"none"}}>Phone</Checkbox>
                    </Stack>
                  </HStack>
                  <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                    <Text color="gray.400" w={"30%"}>
                      Allow Marketing
                    </Text>
                    <Switch size="lg" colorScheme="teal" />
                  </HStack>
                </SimpleGrid>
                <Box py={5} display="flex" justifyContent={"end"} px="5">
                  <Button bg={"gray.100"} color="gray.400" me={2}>
                    Discard
                  </Button>
                  <Button
                    bg={"gray.900"}
                    color="white"
                    _hover={{ bg: "green.500" }}
                  >
                    Save Changes
                  </Button>
                </Box>
              </Box>
            </SimpleGrid>
          </Box>
        </GridItem>
      </Grid>
    </div>
  );
}

export default ProfileEdit;
