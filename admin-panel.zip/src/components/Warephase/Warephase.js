import React from "react";
import {
  Box,
  Stack,
  Text,
  SimpleGrid,
  HStack,
  Link,
  Image,
} from "@chakra-ui/react";
import chart2 from "../../assets/images/chart2.png";
const Warephase = () => {
  return (
    <div>
      {" "}
      <Box
        mb={6}
        p={5}
        bg="white"
        boxShadow="md"
        borderRadius="10"
        position="relative"
      >
        <SimpleGrid>
          <HStack
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            mb={6}
          >
            <Stack spacing={0}>
              <Text fontSize="22.75px" color="gray.800" fontWeight={500}>
              Warephase stats
              </Text>
              <Text fontSize="13px" color="gray.400" fontWeight={500}>
              8k social visitors
              </Text>
            </Stack>
            <Link 
            fontSize="13px"
            color="gray.400"
            fontWeight={500}
            backgroundColor="gray.100"
            px={3}
            py={2} _hover={{textDecoration:"none",color:"green.500", backgroundColor:"green.100"}}
          >
            PDF Report
          </Link>
          </HStack>
          <Image src={chart2} width="100%" />
        </SimpleGrid>
      </Box>
    </div>
  );
};

export default Warephase;
