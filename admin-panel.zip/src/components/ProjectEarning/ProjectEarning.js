import React from "react";
import { Box, Stack, Heading, Text, Image } from "@chakra-ui/react";

const ProjectEarning = () => {
  const image = require("../../assets/images/chartsmall.jpg");

  return (
    <div>
      <Box
        mb={6}
        bg="white"
        boxShadow="md"
        borderRadius={8}
        padding="5"
        color="black"
      >
        <Stack>
          <Heading fontSize="36">69,700</Heading>
          <Text fontSize="16" color="gray.500">
            Projects Earnings in April
          </Text>
        </Stack>

        <Image mt="5" src={image} />
      </Box>
    </div>
  );
};

export default ProjectEarning;
