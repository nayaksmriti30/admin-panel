import React from "react";
import {
  Box,
  Stack,
  HStack,
  Text,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableCaption,
  TableContainer,
  Image,Link
} from "@chakra-ui/react";
import { ArrowForwardIcon, ArrowUpIcon,ArrowDownIcon } from "@chakra-ui/icons";
import social from "../../assets/images/social_chart.png";

const ProjectStats = () => {
  return (
    <div>
      <Box
        mb={6}
        bg="white"
        boxShadow="md"
        borderRadius="10"
        p={5}
        position="relative"
      >
        <HStack
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={6}
        >
          <Stack spacing={0}>
            <Text fontSize="22.75px" color="gray.800" fontWeight={500}>
              Projects Stats
            </Text>
            <Text fontSize="13px" color="gray.400" fontWeight={500}>
              Updated 37 minutes ago
            </Text>
          </Stack>
          <Link 
            fontSize="13px"
            color="gray.400"
            fontWeight={500}
            backgroundColor="gray.100"
            px={3}
            py={2} _hover={{textDecoration:"none",color:"green.500", backgroundColor:"green.100"}}
          >
            History
          </Link>
        </HStack>
        <Stack>
          <TableContainer>
            <Table variant="simple">
              <Thead>
                <Tr>
                  <Th color="gray.400">ITEM</Th>
                  <Th color="gray.400" isNumeric>
                    BUDGET
                  </Th>
                  <Th color="gray.400" isNumeric>
                    PROGRESS
                  </Th>
                  <Th color="gray.400">STATUS</Th>
                  <Th color="gray.400">CHART</Th>
                  <Th color="gray.400">VIEW</Th>
                </Tr>
              </Thead>
              <Tbody>
                <Tr>
                  <Td>
                    
                    <Box display="flex" alignItems="center">
                      <Image
                        src="https://preview.keenthemes.com/metronic8/demo1/assets/media/stock/600x600/img-49.jpg"
                        width={50}
                        height="50px"
                        borderRadius={6}
                      />

                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          Guy Hawkins
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Haiti
                        </Text>
                      </Box>
                    </Box>
                  </Td>
                  <Td textAlign="right">$32,400 </Td>
                  <Td isNumeric>
                  <Text bg="green.50" display="inline-block" p={1} color="green.400"> <ArrowUpIcon w={4} h={4}/>9.2%</Text>
                  </Td>
                  <Td><Text backgroundColor="blue.50" color="blue.500" display="inline-block" py={1} px={2}>In Process</Text></Td>
                  <Td>
                    <Image src={social} />
                  </Td>
                  <Td>
                    <ArrowForwardIcon
                      w={6}
                      h={6}
                      bg="gray.100"
                      color="gray.300"
                      _hover={{ color: "green.300" }}
                    />
                  </Td>
                </Tr>
                <Tr>
                  <Td>
                    <Box display="flex" alignItems="center">
                      <Image
                        src="https://preview.keenthemes.com/metronic8/demo1/assets/media/stock/600x600/img-40.jpg"
                        width={50}
                        height="50px"
                        borderRadius={6}
                      />

                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          Jane Cooper
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Monaco
                        </Text>
                      </Box>
                    </Box>
                  </Td>
                  <Td textAlign="right">$32,400 </Td>
                  <Td isNumeric>
                    <Text bg="red.50" display="inline-block" p={1} color="red.500"><ArrowDownIcon w={4} h={4}/>9.2%</Text>
                  </Td>
                  <Td><Text backgroundColor="yellow.50" color="yellow.500" display="inline-block" py={1} px={2}>On Hold</Text></Td>
                  <Td>
                    <Image src={social} />
                  </Td>
                  <Td>
                    <ArrowForwardIcon
                      w={6}
                      h={6}
                      bg="gray.100"
                      color="gray.300"
                      _hover={{ color: "green.300" }}
                    />
                  </Td>
                </Tr>
                <Tr>
                  <Td>
                    <Box display="flex" alignItems="center">
                      <Image
                        src="https://preview.keenthemes.com/metronic8/demo1/assets/media/stock/600x600/img-39.jpg"
                        width={50}
                        height="50px"
                        borderRadius={6}
                      />

                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          Jacob Jones
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Poland
                        </Text>
                      </Box>
                    </Box>
                  </Td>
                  <Td textAlign="right">$32,400 </Td>
                  <Td isNumeric>
                        <Text bg="green.50" display="inline-block" p={1} color="green.400"> <ArrowUpIcon w={4} h={4} />9.2%</Text>
                  </Td>
                  <Td><Text backgroundColor="blue.50" color="blue.400" display="inline-block" py={1} px={2}>In Process</Text></Td>
                  <Td>
                    <Image src={social} />
                  </Td>
                  <Td>
                    <ArrowForwardIcon
                      w={6}
                      h={6}
                      bg="gray.100"
                      color="gray.300"
                      _hover={{ color: "green.300" }}
                    />
                  </Td>
                </Tr>
                <Tr>
                  <Td>
                    <Box display="flex" alignItems="center">
                      <Image
                        src="https://preview.keenthemes.com/metronic8/demo1/assets/media/stock/600x600/img-47.jpg"
                        width={50}
                        height="50px"
                        borderRadius={6}
                      />

                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          Cody Fishers
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Mexico
                        </Text>
                      </Box>
                    </Box>
                  </Td>
                  <Td textAlign="right">$32,400 </Td>
                  <Td isNumeric >
                  <Text bg="green.50" display="inline-block" p={1} color="green.400"><ArrowUpIcon w={4} h={4} />9.2%</Text>
                  </Td>
                  <Td><Text backgroundColor="green.50" color="green.500"  display="inline-block" py={1} px={2}>Completed</Text></Td>
                  <Td>
                    <Image src={social} />
                  </Td>
                  <Td>
                    <ArrowForwardIcon
                      w={6}
                      h={6}
                      bg="gray.100"
                      color="gray.300"
                      _hover={{ color: "green.300" }}
                    />
                  </Td>
                </Tr>
                <Tr>
                  <Td>
                    <Box display="flex" alignItems="center">
                      <Image
                        src="https://preview.keenthemes.com/metronic8/demo1/assets/media/stock/600x600/img-48.jpg "
                        width={50}
                        height="50px"
                        borderRadius={6}
                      />

                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          Jane Cooper
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Monaco
                        </Text>
                      </Box>
                    </Box>
                  </Td>
                  <Td textAlign="right">$32,400 </Td>
                  <Td isNumeric>
                    <Text bg="red.50" display="inline-block" p={1} color="red.500"><ArrowDownIcon w={4} h={4}/>9.2%</Text>
                  </Td>
                  <Td >
                  <Text backgroundColor="blue.50" color="blue.500" display="inline-block" py={1} px={2}>In Process</Text></Td>
                  <Td>
                    <Image src={social} />
                  </Td>
                  <Td>
                    <ArrowForwardIcon
                      w={6}
                      h={6}
                      bg="gray.100"
                      color="gray.300"
                      _hover={{ color: "green.300" }}
                    />
                  </Td>
                </Tr>
              </Tbody>
            </Table>
          </TableContainer>
        </Stack>
      </Box>
    </div>
  );
};

export default ProjectStats;
