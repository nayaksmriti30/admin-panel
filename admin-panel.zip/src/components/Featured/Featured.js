import React from "react";
import {
  Box,
  Stack,
  Text,
  SimpleGrid,
  HStack,
  Avatar,
  Link,
  Image,
} from "@chakra-ui/react";
import { ExternalLinkIcon, SettingsIcon } from "@chakra-ui/icons";
const Featured = () => {
  return (
    <div>
      <Box
        mb={6}
        p={5}
        bg="white"
        boxShadow="md"
        borderRadius="10"
        position="relative"
      >
        <SimpleGrid columns={2}>
          <Box>
            <Image
              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/stock/600x600/img-65.jpg"
              width={600}
              height={400}
              borderRadius="4"
            ></Image>
          </Box>
          <Box width="100%" py={6} ps={6}>
            <HStack
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              mb={6}
            >
              <Stack spacing={0}>
                <Text fontSize="13px" color="gray.400" fontWeight={500}>
                  Featured
                </Text>
                <Text fontSize="22.75px" color="gray.800" fontWeight={500}>
                  9 Degree
                </Text>
              </Stack>
              <Link 
            fontSize="13px"
            color="gray.400"
            fontWeight={500}
            backgroundColor="gray.100"
            px={3}
            py={2} _hover={{textDecoration:"none",color:"green.500", backgroundColor:"green.100"}}
          >
            In Process
          </Link>
            </HStack>
            <HStack display="flex" mb={7}>
              <Box display="flex" alignItems="center">
                <Avatar name="Smriti Nayak" />

                <Box px={3}>
                  <Text fontSize="11px" color="gray.400" fontWeight={500}>
                    Manager
                  </Text>
                  <Text fontSize="13px" color="gray.800" fontWeight={500}>
                    Robert Fox
                  </Text>
                </Box>
              </Box>
              <Box display="flex" alignItems="center" me={7} px={2}>
                <Box
                  width="40px"
                  height="40px"
                  bg={"green.300"}
                  borderRadius="full"
                  color={"white"}
                  display="flex"
                  alignItems={"center"}
                  justifyContent={"center"}
                >
                  <SettingsIcon />
                </Box>
                <Box ms={2}>
                  <Text fontSize="11px" color="gray.400" fontWeight={500}>
                    Budget
                  </Text>
                  <Text fontSize="13px" color="gray.800" fontWeight={500}>
                    $64.800
                  </Text>
                </Box>
              </Box>
            </HStack>
            <Text
              noOfLines={2}
              fontSize="14px"
              color="gray.500"
              fontWeight={400}
              mb={8}
            >
              Flat cartoony illustrations with vivid unblended colors and
              asymmetrical beautiful purple hair lady
            </Text>
            <HStack display="flex" justifyContent="space-between" mb={7}>
              <Stack
                spacing={0}
                border="1px solid"
                borderColor="gray.500"
                borderStyle="dashed"
                ps={3}
                pe={16}
                py={2}
                textAlign="left"
                borderRadius={5}
              >
                <Text fontSize="14px" color="gray.700" fontWeight={500}>
                  Feb 6, 2021
                </Text>
                <Text fontSize="13px" color="gray.400" fontWeight={500}>
                  Due Date
                </Text>
              </Stack>
              <Stack
                spacing={0}
                border="1px solid"
                borderColor="gray.500"
                borderStyle="dashed"
                ps={3}
                pe={16}
                py={2}
                textAlign="left"
                borderRadius={5}
              >
                <Text fontSize="14px" color="gray.700" fontWeight={500}>
                  $ 284,900
                </Text>
                <Text fontSize="13px" color="gray.400" fontWeight={500}>
                  Budget
                </Text>
              </Stack>
            </HStack>
            <HStack display="flex" justifyContent="space-between">
              <Box display="flex">
                <Image
                  src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-2.jpg"
                  width={30}
                  borderRadius="100%"
                  zIndex={0}
                  position="relative"
                />
                <Image
                  src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-3.jpg"
                  width={30}
                  borderRadius="100%"
                  zIndex={10}
                  position="absolute"
                  mx="5"
                />
                <Image
                  src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-2.jpg"
                  width={30}
                  borderRadius="100%"
                  zIndex={20}
                  position="absolute"
                  mx="10"
                />
              </Box>
              <Box>
                <Link
                  href="https://chakra-ui.com"
                  color="blue.300"
                  fontSize={14}
                  fontWeight={500}
                  isExternal
                >
                  View Projects <ExternalLinkIcon mx="2px" />
                </Link>
              </Box>
            </HStack>
          </Box>
        </SimpleGrid>
      </Box>
    </div>
  );
};

export default Featured;
