import React from "react";
import {
  Box,
  Stack,
  Text,
  SimpleGrid,
  HStack,
  Input,
  Image,
} from "@chakra-ui/react";
import chart1 from "../../assets/images/chart1.PNG";
const Performance = () => {
  return (
    <div>
      {" "}
      <Box
        mb={6}
        p={5}
        bg="white"
        boxShadow="md"
        borderRadius="10"
        position="relative"
      >
        <SimpleGrid>
          <HStack
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            mb={6}
          >
            <Stack spacing={0}>
              <Text fontSize="22.75px" color="gray.800" fontWeight={500}>
                Performance
              </Text>
              <Text fontSize="13px" color="gray.400" fontWeight={500}>
                1,046 Inbound Calls today
              </Text>
            </Stack>
            <Text
              fontSize="13px"
              color="gray.500"
              fontWeight={500}
              backgroundColor="#f5f8fa"
             
            >
              <Input type="date" border={0}  _hover={{textDecoration:"none",color:"green.500", backgroundColor:"green.100"}}/>
            </Text>
          </HStack>
          <Image src={chart1} width="100%" />
        </SimpleGrid>
      </Box>
    </div>
  );
};

export default Performance;
