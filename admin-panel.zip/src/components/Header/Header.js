import React from "react";
import {
  VStack,
  Stack,
  Grid,
  Flex,
  Link,
  DrawerBody,
  Input,
  DrawerCloseButton,
  DrawerFooter,
  Box,
  Drawer,
  useDisclosure,
  Button,
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverHeader,
  PopoverBody,
  PopoverArrow,
  ListItem,
  UnorderedList,
  PopoverCloseButton,
  Avatar,
  WrapItem,
  Text,
  DrawerHeader,
  Image,
  DrawerOverlay,
  DrawerContent,
  Divider,
  border,
} from "@chakra-ui/react";
import {
  PhoneIcon,
  Search2Icon,
  SunIcon,
  ArrowForwardIcon,
  DragHandleIcon,
} from "@chakra-ui/icons";
const Header = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const btnRef = React.useRef();

  return (
    <div>
      <Stack bgColor="white" p="5" width="full" mb={5}>
        <Flex justifyContent="space-between" alignItems="center">
          <Flex>
            <Grid>
              <Flex fontSize="15" fontWeight="600">
                <Link href="/" px={8} color="gray.500" _hover={{textDecoration:"none",color:"green.400"}}>
                  Dashboards
                </Link>
                <Link px={8} color="gray.500" _hover={{textDecoration:"none",color:"green.400"}}>
                  Pages
                </Link>
                <Link px={8} color="gray.500" _hover={{textDecoration:"none",color:"green.400"}}>
                  Apps
                </Link>
                <Link px={8} color="gray.500" _hover={{textDecoration:"none",color:"green.400"}}>
                  Layouts
                </Link>
                <Link px={8} color="gray.500" _hover={{textDecoration:"none",color:"green.400"}}>
                  Help
                </Link>
              </Flex>
            </Grid>
          </Flex>

          <Flex>
            <Grid px={8}>
              <Flex>
                <Button
                  px={4}
                  onClick={onOpen}
                  ref={btnRef}
                  bg="none"
                  color="gray.500" _hover={{color:"green.500", backgroundColor:"green.100"}}
                >
                  <Search2Icon />
                </Button>
                <Drawer
                  isOpen={isOpen}
                  placement="left"
                  onClose={onClose}
                  finalFocusRef={btnRef}
                  color={"gray.100"}
                  
                >
                  <DrawerOverlay />
                  <DrawerContent>
                    <DrawerCloseButton color={"white"} mt={2}/>
                    <DrawerHeader bg="black" color={"gray.300"}>Search here</DrawerHeader>

                    <DrawerBody bg="gray.900" color={"gray.300"}>
                      <Input placeholder="Type here..." _focus={{boxShadow:"none",borderColor:"white" }} _active={{boxShadow:"none" }}/>
                      <Button
                        mt={3}
                        width="100%"
                        backgroundColor="green.400"
                        color="white"
                        _hover={{
                          color: "green.500",
                          backgroundColor: "green.100",
                        }}
                      >
                        Search
                      </Button>
                    </DrawerBody>
                  </DrawerContent>
                </Drawer>

                <Popover>
                  <PopoverTrigger>
                    <WrapItem px="4">
                      <Link><Avatar
                        name="Dan Abrahmov"
                        src="https://bit.ly/dan-abramov"
                      />
                      </Link>
                      
                    </WrapItem>
                  </PopoverTrigger>
                  <PopoverContent boxShadow="md" _focus={{boxShadow:"none"}}>
                    <PopoverArrow />
                    <PopoverCloseButton />
                    <PopoverHeader fontWeight="bold" p={3}>
                      <Box display="flex" alignItems="center">
                        <Image
                          src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-3.jpg"
                          width={50}
                          height="50px"
                          borderRadius={6}
                        />

                        <Box px={3}>
                          <Text
                            fontSize="13px"
                            color="gray.800"
                            fontWeight={500}
                          >
                            Guy Hawkins
                          </Text>
                          <Text
                            fontSize="11px"
                            color="gray.400"
                            fontWeight={500}
                          >
                            Haiti
                          </Text>
                        </Box>
                      </Box>
                    </PopoverHeader>
                    <PopoverBody>
                      <UnorderedList listStyleType="none" m="0">
                        <ListItem m="0">
                          <Link
                            display="block"
                            py={2}
                            px={3}
                            borderRadius={4}
                            _hover={{
                              color: "green.500",
                              textDecoration: "none",
                              backgroundColor: "green.100",
                            }}
                          >
                            My Profile
                          </Link>
                        </ListItem>
                        <ListItem m="0">
                          <Link
                            display="block"
                            py={2}
                            px={3}
                            borderRadius={4}
                            _hover={{
                              color: "green.500",
                              textDecoration: "none",
                              backgroundColor: "green.100",
                            }}
                          >
                            My Projects
                          </Link>
                        </ListItem>
                        <ListItem m="0">
                          <Link
                            display="block"
                            py={2}
                            px={3}
                            borderRadius={4}
                            _hover={{
                              color: "green.500",
                              textDecoration: "none",
                              backgroundColor: "green.100",
                            }}
                          >
                            My Statements
                          </Link>
                        </ListItem>
                        <ListItem m="0">
                          <Link
                            display="block"
                            py={2}
                            px={3}
                            borderRadius={4}
                            _hover={{
                              color: "green.500",
                              textDecoration: "none",
                              backgroundColor: "green.100",
                            }}
                          >
                            Account Settings
                          </Link>
                        </ListItem>
                        <Divider />
                        <ListItem m="0">
                          <Link
                            display="block"
                            py={2}
                            px={3}
                            borderRadius={4}
                            _hover={{
                              color: "green.500",
                              textDecoration: "none",
                              backgroundColor: "green.100",
                            }}
                          >
                            Sign Out
                          </Link>
                        </ListItem>
                      </UnorderedList>
                    </PopoverBody>
                  </PopoverContent>
                </Popover>
              </Flex>
            </Grid>
          </Flex>
        </Flex>
      </Stack>
    </div>
  );
};

export default Header;
