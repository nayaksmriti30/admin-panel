import React from "react";
import {
  Box,
  Stack,
  HStack,
  Text,
  Tabs,
  TabList,
  Tab,
  TabPanels,
  TabPanel,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
  Image,
  Link,
  PopoverHeader,
  PopoverCloseButton,
  PopoverArrow,
  PopoverContent,
  PopoverBody,
  Popover,
  PopoverTrigger,
  Button,
  UnorderedList,
  ListItem,
  border,
} from "@chakra-ui/react";
import { ArrowForwardIcon, DragHandleIcon } from "@chakra-ui/icons";
import social from "../../assets/images/social_chart.png";

const Achievment = () => {
  return (
    <div>
      <Box
        mb={6}
        bg="white"
        boxShadow="md"
        borderRadius="10"
        p={5}
        position="relative"
      >
        <HStack
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={6}
        >
          <Stack spacing={0}>
            <Text fontSize="22.75px" color="gray.800" fontWeight={500}>
              Authors Achievements
            </Text>
            <Text fontSize="13px" color="gray.400" fontWeight={500}>
              Avg. 69.34% Conv. Rate
            </Text>
          </Stack>
          <Popover placement="right" boxShadow="xl">
            <PopoverTrigger>
              <Button  _hover={{textDecoration:"none",color:"green.500", backgroundColor:"green.100"}}>
                <DragHandleIcon />
              </Button>
            </PopoverTrigger>
            <PopoverContent boxShadow="xl">
              <PopoverArrow />
              <PopoverCloseButton />
              <PopoverHeader fontWeight="bold" p={3}>
                Quick Actions
              </PopoverHeader>
              <PopoverBody>
                <UnorderedList listStyleType="none" m="0">
                  <ListItem m="0">
                    <Link
                      display="block"
                      py={2}
                      px={3}
                      borderRadius={4}
                      _hover={{
                        color: "green.500",
                        textDecoration: "none",
                        backgroundColor: "green.100",
                      }}
                    >
                      New Ticket
                    </Link>
                  </ListItem>
                  <ListItem m="0">
                    <Link
                      display="block"
                      py={2}
                      px={3}
                      borderRadius={4}
                      _hover={{
                        color: "green.500",
                        textDecoration: "none",
                        backgroundColor: "green.100",
                      }}
                    >
                      New Customer
                    </Link>
                  </ListItem>
                  <ListItem m="0">
                    <Link
                      display="block"
                      py={2}
                      px={3}
                      borderRadius={4}
                      _hover={{
                        color: "green.500",
                        textDecoration: "none",
                        backgroundColor: "green.100",
                      }}
                    >
                      New Group
                    </Link>
                  </ListItem>
                  <ListItem m="0">
                    <Link
                      display="block"
                      py={2}
                      px={3}
                      borderRadius={4}
                      _hover={{
                        color: "green.500",
                        textDecoration: "none",
                        backgroundColor: "green.100",
                      }}
                    >
                      New Contact
                    </Link>
                  </ListItem>
                </UnorderedList>
              </PopoverBody>
            </PopoverContent>
          </Popover>
        </HStack>
        <Stack>
          <Tabs>
            <TabList my={3} borderBottom={0}>
              <Tab
                mx={3}
                border="1px"
                color={"gray.500"}
                borderStyle="solid"
                borderColor="gray.400" fontWeight="500"
                borderRadius={6}
                _hover={{textDecoration:"none",color:"green.500", backgroundColor:"green.100"}}
                _focus={{ boxShadow: "0 3px 0 0 rgba(56,161,105,1)",color:"green.500" }}
                _active={{ boxShadow: "0 3px 0 0 rgba(56,161,105,1)",color:"green.500" }}
              >
                SaaS
              </Tab>
              <Tab
                mx={3}
                border="1px"
                color={"gray.500"}
                borderStyle="solid"
                borderColor="gray.400" fontWeight="500"
                borderRadius={6}
                _hover={{textDecoration:"none",color:"green.500", backgroundColor:"green.100",fontWeight:"500"}}
                _focus={{ boxShadow: "0 3px 0 0 rgba(56,161,105,1)",color:"green.500" }}
                _active={{ boxShadow: "0 3px 0 0 rgba(56,161,105,1)",color:"green.500" }}
              >
                Crypto
              </Tab>
              <Tab
                mx={3}
                border="1px"
                color={"gray.500"}
                borderStyle="solid"
                borderColor="gray.400" fontWeight="500"
                borderRadius={6}
                _hover={{textDecoration:"none",color:"green.500", backgroundColor:"green.100",fontWeight:"500"}}
                _focus={{ boxShadow: "0 3px 0 0 rgba(56,161,105,1)",color:"green.500" }}
                _active={{ boxShadow: "0 3px 0 0 rgba(56,161,105,1)",color:"green.500" }}
              >
                Social
              </Tab>
              <Tab
                mx={3}
                border="1px"
                color={"gray.500"}
                borderStyle="solid" fontWeight="500"
                borderColor="gray.400"
                borderRadius={6}
                _hover={{textDecoration:"none",color:"green.500", backgroundColor:"green.100",fontWeight:"500"}}
                _focus={{ boxShadow: "0 3px 0 0 rgba(56,161,105,1)",color:"green.500" }}
                _active={{ boxShadow: "0 3px 0 0 rgba(56,161,105,1)",color:"green.500" }}
              >
                Crypto
              </Tab>
              <Tab
                mx={3}
                border="1px"
                color={"gray.500"}
                borderStyle="solid"
                borderColor="gray.400" fontWeight="500"
                borderRadius={6}
                _hover={{textDecoration:"none",color:"green.500", backgroundColor:"green.100",fontWeight:"500"}}
                _focus={{ boxShadow: "0 3px 0 0 rgba(56,161,105,1)",color:"green.500" }}
                _active={{ boxShadow: "0 3px 0 0 rgba(56,161,105,1)",color:"green.500" }}
              >
                Crypto
              </Tab>
            </TabList>
            <TabPanels>
              <TabPanel p={0}>
                <TableContainer>
                  <Table variant="simple">
                    <Thead>
                      <Tr>
                        <Th color="gray.400">AUTHOR</Th>
                        <Th color="gray.400" textAlign="left">
                          CONV.
                        </Th>
                        <Th color="gray.400">CHART</Th>
                        <Th color="gray.400">VIEW</Th>
                      </Tr>
                    </Thead>
                    <Tbody>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-3.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Guy Hawkins
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Haiti
                              </Text>
                            </Box>
                          </Box>
                        </Td>

                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-2.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Jane Cooper
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Monaco
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-9.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Jacob Jones
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Poland
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-7.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Cody Fishers
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Mexico
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                    </Tbody>
                  </Table>
                </TableContainer>
              </TabPanel>
              <TabPanel p={0}>
                <TableContainer>
                  <Table variant="simple">
                    <Thead>
                      <Tr>
                        <Th color="gray.400">AUTHOR</Th>
                        <Th color="gray.400" textAlign="left">
                          CONV.
                        </Th>
                        <Th color="gray.400">CHART</Th>
                        <Th color="gray.400">VIEW</Th>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-9.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Jacob Jones
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Poland
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                    </Thead>
                    <Tbody>
                     
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-2.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Jane Cooper
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Monaco
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                     
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-7.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Cody Fishers
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Mexico
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-3.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Guy Hawkins
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Haiti
                              </Text>
                            </Box>
                          </Box>
                        </Td>

                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                    </Tbody>
                  </Table>
                </TableContainer>
              </TabPanel>
              <TabPanel p={0}>
                <TableContainer>
                  <Table variant="simple">
                    <Thead>
                      <Tr>
                        <Th color="gray.400">AUTHOR</Th>
                        <Th color="gray.400" textAlign="left">
                          CONV.
                        </Th>
                        <Th color="gray.400">CHART</Th>
                        <Th color="gray.400">VIEW</Th>
                      </Tr>
                    </Thead>
                    <Tbody>
                     
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-2.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Jane Cooper
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Monaco
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-7.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Cody Fishers
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Mexico
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-9.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Jacob Jones
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Poland
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-3.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Guy Hawkins
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Haiti
                              </Text>
                            </Box>
                          </Box>
                        </Td>

                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      
                    </Tbody>
                  </Table>
                </TableContainer>
              </TabPanel>
              <TabPanel p={0}>
                <TableContainer>
                  <Table variant="simple">
                    <Thead>
                      <Tr>
                        <Th color="gray.400">AUTHOR</Th>
                        <Th color="gray.400" textAlign="left">
                          CONV.
                        </Th>
                        <Th color="gray.400">CHART</Th>
                        <Th color="gray.400">VIEW</Th>
                      </Tr>
                    </Thead>
                    <Tbody>
                     

                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-2.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Jane Cooper
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Monaco
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-7.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Cody Fishers
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Mexico
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-9.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Jacob Jones
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Poland
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-3.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Guy Hawkins
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Haiti
                              </Text>
                            </Box>
                          </Box>
                        </Td>

                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                    </Tbody>
                  </Table>
                </TableContainer>
              </TabPanel>
              <TabPanel p={0}>
                <TableContainer>
                  <Table variant="simple">
                    <Thead>
                      <Tr>
                        <Th color="gray.400">AUTHOR</Th>
                        <Th color="gray.400" textAlign="left">
                          CONV.
                        </Th>
                        <Th color="gray.400">CHART</Th>
                        <Th color="gray.400">VIEW</Th>
                      </Tr>
                    </Thead>
                    <Tbody>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-7.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Cody Fishers
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Mexico
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-3.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Guy Hawkins
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Haiti
                              </Text>
                            </Box>
                          </Box>
                        </Td>

                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-9.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Jacob Jones
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Poland
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                      <Tr>
                        <Td>
                          {" "}
                          <Box display="flex" alignItems="center">
                            <Image
                              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-2.jpg"
                              width={50}
                              height="50px"
                              borderRadius={6}
                            />

                            <Box px={3}>
                              <Text
                                fontSize="13px"
                                color="gray.800"
                                fontWeight={500}
                              >
                                Jane Cooper
                              </Text>
                              <Text
                                fontSize="11px"
                                color="gray.400"
                                fontWeight={500}
                              >
                                Monaco
                              </Text>
                            </Box>
                          </Box>
                        </Td>
                        <Td textAlign="left">78.34%</Td>
                        <Td>
                          <Image src={social} />
                        </Td>
                        <Td>
                          <ArrowForwardIcon
                            w={6}
                            h={6}
                            bg="gray.100"
                            color="gray.300"
                            _hover={{ color: "green.300" }}
                          />
                        </Td>
                      </Tr>
                    </Tbody>
                  </Table>
                </TableContainer>
              </TabPanel>
            </TabPanels>
          </Tabs>
        </Stack>
      </Box>
    </div>
  );
};

export default Achievment;
