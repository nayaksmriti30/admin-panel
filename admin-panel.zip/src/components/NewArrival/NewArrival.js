import React from "react";
import {
  Flex,
  Box,
  Stack,
  HStack,
  Text,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
  Image,
  Link,
  SimpleGrid,
  Switch,
  Input,
  Select,
  IconButton,
  Button,
} from "@chakra-ui/react";
import {
  ChevronRightIcon,
  DeleteIcon,
  ChevronLeftIcon,
  SearchIcon,
  EditIcon,
  AddIcon,
} from "@chakra-ui/icons";

import social from "../../assets/images/social_chart.png";

function NewArrival() {
  return (
    <div>
      <SimpleGrid>
        <Box
          mb={6}
          bg="white"
          boxShadow="md"
          borderRadius="10"
          p={5}
          position="relative"
        >
          <HStack
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            mb={6}
          >
            <Stack spacing={0}>
              <Text fontSize="22.75px" color="gray.800" fontWeight={500}>
                New Arrivals
              </Text>
              <Text fontSize="13px" color="gray.400" fontWeight={500}>
                Over 500 new products
              </Text>
            </Stack>

            <Link
              fontSize="13px"
              color="gray.400"
              fontWeight={500}
              backgroundColor="gray.100"
              px={3}
              py={2}
              _hover={{
                textDecoration: "none",
                color: "green.500",
                backgroundColor: "green.100",
              }}
            >
              <AddIcon w={4} h={3} /> New Member
            </Link>
          </HStack>
          <HStack mb={4} justifyContent={"space-between"}>
            <Flex align={"center"}>
              <Text>Show</Text>
              <Select maxW={100} mx={2}>
                <option value="option1">10</option>
                <option value="option2">20</option>
                <option value="option3">50</option>
              </Select>
              <Text>Enteries</Text>
            </Flex>
            <Box maxW={300}>
              <Input placeholder="Search here.." />
            </Box>
          </HStack>

          <Stack>
            <TableContainer>
              <Table variant="simple">
                <Thead>
                  <Tr bg={"gray.50"} boxShadow={0} borderRadius={8}>
                    <Th color="gray.400">ITEM</Th>
                    <Th color="gray.400" isNumeric>
                      BUDGET
                    </Th>
                    <Th color="gray.400" isNumeric>
                      PROGRESS
                    </Th>
                    <Th color="gray.400">STATUS</Th>
                    <Th color="gray.400">OPTION</Th>
                    <Th color="gray.400">CHART</Th>
                    <Th color="gray.400">ACTIONS</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  <Tr>
                    <Td>
                      <Box display="flex" alignItems="center">
                        <Image
                          src="https://preview.keenthemes.com/metronic8/demo1/assets/media/stock/600x600/img-49.jpg"
                          width={50}
                          height="50px"
                          borderRadius={6}
                        />

                        <Box px={3}>
                          <Text
                            fontSize="13px"
                            color="gray.800"
                            fontWeight={500}
                          >
                            Sant Extreanet Solution
                          </Text>
                          <Text
                            fontSize="11px"
                            color="gray.400"
                            fontWeight={500}
                          >
                            HTML, JS, ReactJS
                          </Text>
                        </Box>
                      </Box>
                    </Td>
                    <Td textAlign="right">
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          $2,790
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Paid
                        </Text>
                      </Box>{" "}
                    </Td>
                    <Td isNumeric>
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          $520
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Rejected
                        </Text>
                      </Box>
                    </Td>
                    <Td>
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          Bradly Beal
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Insurance
                        </Text>
                      </Box>
                    </Td>
                    <Td>
                      <Switch size="md" colorScheme="teal" />
                    </Td>
                    <Td>
                      <Text
                        backgroundColor="blue.50"
                        color="blue.500"
                        display="inline-block"
                        py={1}
                        px={2}
                      >
                        Approved
                      </Text>
                    </Td>

                    <Td>
                      <Link>
                        <EditIcon
                          w={5}
                          h={5}
                          color="gray.400"
                          me={4}
                          _hover={{ color: "green.400" }}
                        />
                      </Link>
                      <Link>
                        <DeleteIcon
                          w={5}
                          h={5}
                          color="gray.400"
                          _hover={{ color: "green.400" }}
                        />
                      </Link>
                    </Td>
                  </Tr>
                  <Tr>
                    <Td>
                      <Box display="flex" alignItems="center">
                        <Image
                          src="https://preview.keenthemes.com/metronic8/demo1/assets/media/stock/600x600/img-40.jpg"
                          width={50}
                          height="50px"
                          borderRadius={6}
                        />

                        <Box px={3}>
                          <Text
                            fontSize="13px"
                            color="gray.800"
                            fontWeight={500}
                          >
                            Telegram Development
                          </Text>
                          <Text
                            fontSize="11px"
                            color="gray.400"
                            fontWeight={500}
                          >
                            C#, ASP.NET, MS SQL
                          </Text>
                        </Box>
                      </Box>
                    </Td>
                    <Td textAlign="right">
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          $2,790
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Paid
                        </Text>
                      </Box>{" "}
                    </Td>
                    <Td isNumeric>
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          $520
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Rejected
                        </Text>
                      </Box>
                    </Td>
                    <Td>
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          Bradly Beal
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Insurance
                        </Text>
                      </Box>
                    </Td>
                    <Td>
                      <Switch size="md" colorScheme="teal" />
                    </Td>
                    <Td>
                      <Text
                        backgroundColor="red.50"
                        color="red.500"
                        display="inline-block"
                        py={1}
                        px={2}
                      >
                        In Progress
                      </Text>
                    </Td>

                    <Td>
                      <Link>
                        <EditIcon
                          w={5}
                          h={5}
                          color="gray.400"
                          me={4}
                          _hover={{ color: "green.400" }}
                        />
                      </Link>
                      <Link>
                        <DeleteIcon
                          w={5}
                          h={5}
                          color="gray.400"
                          _hover={{ color: "green.400" }}
                        />
                      </Link>
                    </Td>
                  </Tr>
                  <Tr>
                    <Td>
                      <Box display="flex" alignItems="center">
                        <Image
                          src="https://preview.keenthemes.com/metronic8/demo1/assets/media/stock/600x600/img-39.jpg"
                          width={50}
                          height="50px"
                          borderRadius={6}
                        />

                        <Box px={3}>
                          <Text
                            fontSize="13px"
                            color="gray.800"
                            fontWeight={500}
                          >
                            Payroll Application
                          </Text>
                          <Text
                            fontSize="11px"
                            color="gray.400"
                            fontWeight={500}
                          >
                            PHP, Laravel, VueJS
                          </Text>
                        </Box>
                      </Box>
                    </Td>
                    <Td textAlign="right">
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          $2,790
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Paid
                        </Text>
                      </Box>{" "}
                    </Td>
                    <Td isNumeric>
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          $520
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Rejected
                        </Text>
                      </Box>
                    </Td>
                    <Td>
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          Bradly Beal
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Insurance
                        </Text>
                      </Box>
                    </Td>
                    <Td>
                      <Switch size="md" colorScheme="teal" />
                    </Td>
                    <Td>
                      <Text
                        backgroundColor="green.50"
                        color="green.500"
                        display="inline-block"
                        py={1}
                        px={2}
                      >
                        Success
                      </Text>
                    </Td>

                    <Td>
                      <Link>
                        <EditIcon
                          w={5}
                          h={5}
                          color="gray.400"
                          me={4}
                          _hover={{ color: "green.400" }}
                        />
                      </Link>
                      <Link>
                        <DeleteIcon
                          w={5}
                          h={5}
                          color="gray.400"
                          _hover={{ color: "green.400" }}
                        />
                      </Link>
                    </Td>
                  </Tr>
                  <Tr>
                    <Td>
                      <Box display="flex" alignItems="center">
                        <Image
                          src="https://preview.keenthemes.com/metronic8/demo1/assets/media/stock/600x600/img-47.jpg"
                          width={50}
                          height="50px"
                          borderRadius={6}
                        />

                        <Box px={3}>
                          <Text
                            fontSize="13px"
                            color="gray.800"
                            fontWeight={500}
                          >
                            HR Management System
                          </Text>
                          <Text
                            fontSize="11px"
                            color="gray.400"
                            fontWeight={500}
                          >
                            Python, PostgreSQL, ReactJS
                          </Text>
                        </Box>
                      </Box>
                    </Td>
                    <Td textAlign="right">
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          $2,790
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Paid
                        </Text>
                      </Box>{" "}
                    </Td>
                    <Td isNumeric>
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          $520
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Rejected
                        </Text>
                      </Box>
                    </Td>
                    <Td>
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          Bradly Beal
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Insurance
                        </Text>
                      </Box>
                    </Td>
                    <Td>
                      <Switch size="md" colorScheme="teal" />
                    </Td>
                    <Td>
                      <Text
                        backgroundColor="purple.50"
                        color="purple.500"
                        display="inline-block"
                        py={1}
                        px={2}
                      >
                        Approved
                      </Text>
                    </Td>

                    <Td>
                      <Link>
                        <EditIcon
                          w={5}
                          h={5}
                          color="gray.400"
                          me={4}
                          _hover={{ color: "green.400" }}
                        />
                      </Link>
                      <Link>
                        <DeleteIcon
                          w={5}
                          h={5}
                          color="gray.400"
                          _hover={{ color: "green.400" }}
                        />
                      </Link>
                    </Td>
                  </Tr>
                  <Tr>
                    <Td>
                      <Box display="flex" alignItems="center">
                        <Image
                          src="https://preview.keenthemes.com/metronic8/demo1/assets/media/stock/600x600/img-48.jpg "
                          width={50}
                          height="50px"
                          borderRadius={6}
                        />

                        <Box px={3}>
                          <Text
                            fontSize="13px"
                            color="gray.800"
                            fontWeight={500}
                          >
                            Telegram Mobile
                          </Text>
                          <Text
                            fontSize="11px"
                            color="gray.400"
                            fontWeight={500}
                          >
                            HTML, JS, ReactJS
                          </Text>
                        </Box>
                      </Box>
                    </Td>
                    <Td textAlign="right">
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          $2,790
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Paid
                        </Text>
                      </Box>{" "}
                    </Td>
                    <Td isNumeric>
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          $520
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Rejected
                        </Text>
                      </Box>
                    </Td>
                    <Td>
                      <Box px={3}>
                        <Text fontSize="13px" color="gray.800" fontWeight={500}>
                          Bradly Beal
                        </Text>
                        <Text fontSize="11px" color="gray.400" fontWeight={500}>
                          Insurance
                        </Text>
                      </Box>
                    </Td>
                    <Td>
                      <Switch size="md" colorScheme="teal" />
                    </Td>
                    <Td>
                      <Text
                        backgroundColor="blue.50"
                        color="blue.500"
                        display="inline-block"
                        py={1}
                        px={2}
                      >
                        Approved
                      </Text>
                    </Td>

                    <Td>
                      <Link>
                        <EditIcon
                          w={5}
                          h={5}
                          color="gray.400"
                          me={4}
                          _hover={{ color: "green.400" }}
                        />
                      </Link>
                      <Link>
                        <DeleteIcon
                          w={5}
                          h={5}
                          color="gray.400"
                          _hover={{ color: "green.400" }}
                        />
                      </Link>
                    </Td>
                  </Tr>
                </Tbody>
              </Table>
            </TableContainer>
          </Stack>
          <HStack justifyContent={"space-between"} mt={4}>
            <Text>Showing 1 to 10 of 57 entries</Text>
            <Box>
              <IconButton
                aria-label="Search database"
                borderRadius={0} 
                bg="gray.400"
                icon={<ChevronLeftIcon />} _hover={{bg:"gray.500"}}
              />
              <Button
                variant="outline"
                bg="gray.100"
                border={0}
                mx={2}
                borderRadius={0}
                _hover={{
                  color: "green.500",
                  backgroundColor: "green.100",
                }}
              >
                1
              </Button>
              <Button
                variant="outline"
                bg="gray.100"
                border={0}
                borderRadius={0}
                mx={2}
                _hover={{
                  color: "green.500",
                  backgroundColor: "green.100",
                }}
              >
                2
              </Button>
              <Button
                variant="outline"
                bg="gray.100"
                border={0}
                borderRadius={0}
                mx={2}
                _hover={{
                  color: "green.500",
                  backgroundColor: "green.100",
                }}
              >
                3
              </Button>

              <IconButton
                aria-label="Search database"
                borderRadius={0} 
                bg="gray.400"
                icon={<ChevronRightIcon />} _hover={{bg:"gray.500"}}
              />
            </Box>
          </HStack>
        </Box>
      </SimpleGrid>
    </div>
  );
}

export default NewArrival;
