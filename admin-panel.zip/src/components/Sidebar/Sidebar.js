import React, { useState } from "react";
import {
  Accordion,
  AccordionItem,
  AccordionButton,
  Box,
  AccordionIcon,
  AccordionPanel,
  UnorderedList,
  ListItem,
  Link,
  Heading,
  Flex,
  Image,
  Stack,
} from "@chakra-ui/react";
import { sidebarData } from "../../helpers/constrants";

const Sidebar = () => {
  const [data, setData] = useState(sidebarData);
  const logo =require("../../assets/images/logo.png")
  console.log(data);
  return (
    <div>
      <Box
        bgColor="gray.900"
        overflowY="auto"
        position="fixed"
        width="300px"
        height="full"
      >
        <Stack py="4" bgColor="black" ps={3}>
          <Image
            src={logo}
            maxW="110px"
          />
        </Stack>

        <Accordion allowMultiple textColor="white">
          {data?.map((item, key) => {
            return (
              <AccordionItem key={key} border="none">
                <h2>
                  <AccordionButton py="5" textColor="gray.400" ps="10">
                    <Box flex="1" textAlign="left" position="relative">
                      {item.menu}
                      {item.icon}
                    </Box>
                    <AccordionIcon />
                  </AccordionButton>
                </h2>
                <AccordionPanel pb={4}>
                  <UnorderedList ps={4}>
                    {item.submenu.map((itemSubmenu, key) => (
                      <ListItem mb={3} border="0">
                        <Link to="" textColor="gray.300">
                          {itemSubmenu}
                        </Link>
                      </ListItem>
                    ))}
                  </UnorderedList>
                </AccordionPanel>
              </AccordionItem>
            );
          })}
        </Accordion>
      </Box>
    </div>
  );
};

export default Sidebar;
