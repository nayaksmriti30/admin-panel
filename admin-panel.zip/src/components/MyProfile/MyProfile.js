import React from "react";
import {
  HStack,
  Text,
  Stack,
  BreadcrumbLink,
  BreadcrumbItem,
  Breadcrumb,
  SimpleGrid,
  Box,
  Image,
  ListItem,
  Grid,
  Button,
  UnorderedList,
  Table,
  Tr,
  Th,
  Td,Link,
  TableCaption,
  TableContainer,
} from "@chakra-ui/react";
import {
  InfoIcon,
  EmailIcon,
  PhoneIcon,InfoOutlineIcon ,
  ArrowUpIcon,
  ArrowDownIcon,
} from "@chakra-ui/icons";
function MyProfile() {
  return (
    <div>
      <HStack
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={6}
      >
        <Stack spacing={0}>
          <Text fontSize="18px" color="gray.800" fontWeight={500}>
            Account Settings
          </Text>

          <Breadcrumb
            separator="-"
            fontSize="13px"
            color="gray.400"
            fontWeight={500}
          >
            <BreadcrumbItem>
              <BreadcrumbLink href="#">Home</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbItem>
              <BreadcrumbLink href="#">Account</BreadcrumbLink>
            </BreadcrumbItem>
          </Breadcrumb>
        </Stack>
      </HStack>
      <SimpleGrid>
        <Box
          mb={6}
          bg="white"
          boxShadow="md"
          borderRadius="10"
          p={5}
          position="relative"
          display={"flex"}
        >
          <HStack position={"relative"}>
            <Image
              src="https://preview.keenthemes.com/metronic8/demo1/assets/media/avatars/300-1.jpg"
              w={160}
              h={160}
              borderRadius={5}
            />
            <Box
              bg="green.300"
              right={"-10px"}
              bottom={6}
              p={1.5}
              position={"absolute"}
              color="white"
              borderRadius={"100%"}
              border={"3px solid white"}
            ></Box>
          </HStack>
          <Box px={"4"}>
            <Text fontSize="20px" mb={"1"} fontWeight={500}>
              Max Smith
            </Text>
            <UnorderedList
              listStyleType={"none"}
              display={"flex"}
              fontSize={"14px"}
              color={"gray.400"}
              ms={"0"}
              mb={"8"}
            >
              <ListItem me={3}>
                <InfoIcon w={4} h={4} /> Developer
              </ListItem>
              <ListItem me={3}>
                {" "}
                <PhoneIcon w={3} h={3} />
                +91 4444 4444
              </ListItem>
              <ListItem me={3}>
                {" "}
                <EmailIcon w={4} h={4} me={1} />
                max@kt.com
              </ListItem>
            </UnorderedList>
            <HStack>
              <Box
                border={"1px dashed"}
                borderColor={"gray.300"}
                display={"inline-block"}
                px={"4"}
                py={"2"}
              >
                <Text fontSize="20px" color="gray.800" fontWeight={500}>
                  <ArrowUpIcon w={"5"} h={"5"} color={"green.400"} />
                  $4,500
                </Text>
                <Text fontSize="14px" color="gray.400" fontWeight={500}>
                  Earnings
                </Text>
              </Box>
              <Box
                border={"1px dashed"}
                borderColor={"gray.300"}
                display={"inline-block"}
                px={"8"}
                py={"2"}
              >
                <Text fontSize="20px" color="gray.800" fontWeight={500}>
                  <ArrowDownIcon w={"5"} h={"5"} color={"red.400"} />
                  75
                </Text>
                <Text fontSize="14px" color="gray.400" fontWeight={500}>
                  Projects
                </Text>
              </Box>
              <Box
                border={"1px dashed"}
                borderColor={"gray.300"}
                display={"inline-block"}
                px={"4"}
                py={"2"}
              >
                <Text fontSize="20px" color="gray.800" fontWeight={500}>
                  <ArrowUpIcon w={"5"} h={"5"} color={"green.400"} />
                  %60
                </Text>
                <Text fontSize="14px" color="gray.400" fontWeight={500}>
                  Success Rate
                </Text>
              </Box>
            </HStack>
          </Box>
        </Box>
      </SimpleGrid>
      <SimpleGrid>
        <Box
          mb={6}
          bg="white"
          boxShadow="md"
          borderRadius="10"
          position="relative"
        >
          <Box
            display={"flex"}
            justifyContent="space-between"
            borderBottom={"1px solid"}
            borderColor={"gray.300"}
            p={4}
            pb={5}
          >
            <Text fontSize="20px" color="gray.800" fontWeight={500}>
              Profile Details
            </Text>

            <Link href="/ProfileEdit"
            fontSize="13px"
            color="gray.600"
            fontWeight={500}
            backgroundColor="gray.200"
            px={3}
            py={2} _hover={{textDecoration:"none",color:"green.600", backgroundColor:"green.100"}}
          >
            Edit Profile
          </Link>
          </Box>
          <SimpleGrid columns={1} spacing={3} p={4}>
           
              <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                <Text color="gray.400" w={"30%"}>Full Name</Text>
                <Text w={"70%"}>Max Smith</Text>
              </HStack>
              <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
                <Text color="gray.400"  w={"30%"}>Company</Text>
                <Text  w={"70%"}>Keenthemes</Text>
              </HStack>
              <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
              <Text color="gray.400"  w={"30%"}>Contact Phone  <InfoOutlineIcon w={4} h={4} bg={"gray.500"} borderRadius={"100%"} color="gray.200"/></Text>
              <Text  w={"70%"}>044 3276 454 935</Text>
              </HStack>
              <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
              <Text color="gray.400"  w={"30%"}>Company Site</Text>
              <Text  w={"70%"}>keenthemes.com</Text>
              </HStack>
              <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
              <Text color="gray.400" w={"30%"}>Country <InfoOutlineIcon w={4} h={4} bg={"gray.500"} borderRadius={"100%"} color="gray.200"/></Text>
              <Text  w={"70%"}>Germany</Text>
              </HStack>
              <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
              <Text color="gray.400" w={"30%"}>Communication </Text>
              <Text  w={"70%"}>Email, Phone</Text>
              </HStack>
              <HStack border={0} fontWeight={500} fontSize={"14px"} pb={3}>
              <Text color="gray.400" w={"30%"}>Allow Changes </Text>
              <Text  w={"70%"}>Yes</Text>
              </HStack>
          
          </SimpleGrid>
        </Box>
      </SimpleGrid>
    </div>
  );
}

export default MyProfile;
