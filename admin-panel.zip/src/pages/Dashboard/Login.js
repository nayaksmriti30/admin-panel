import React from "react";
import {
  SimpleGrid,
  Box,
  Image,
  Heading,
  Text,
  Container,
  Grid,
  GridItem,
  Link,
  Button,
  FormControl,
  Checkbox,
  Input,
  FormHelperText,
  List,
  ListItem,
} from "@chakra-ui/react";
import Login_bg from "../../assets/images/auth-bg.png";
import screen from "../../assets/images/auth-screens.png";
import google from "../../assets/images/gmail.png";
import fb from "../../assets/images/fb.png";


function Login() {
  const logo = require("../../assets/images/logo.png");
  return (
    <div>
      <SimpleGrid columns={2}>
        <Box display={"flex"} alignItems="center">
          <Container textAlign={"center"} margin="auto">
            <Heading fontSize="23" mb={3}>
              Sign up
            </Heading>
            <Text fontSize="14" color={"gray.500"} mb={"35px"}>
              Your Social Campaigns
            </Text>
            <Grid templateColumns="repeat(2, 1fr)" gap={2}>
              <GridItem w="100%">
                <Link
                  display={"flex"}
                  alignItems={"center"}
                  justifyContent={"center"}
                  rounded="md"
                  bg="white"
                  fontSize={14}
                  border={1}
                  borderStyle="solid"
                  borderColor="gray.200"
                  padding={"10px 20px"}
                  borderRadius={6}
                  _hover={{
                    textDecoration: "none",
                    color: "blue.400",
                    bgColor: "gray.200",
                  }}
                >
                  <Image
                    src={google}
                    w={15}
                    h={15}
                    me={2}
                  />
                  Sign in with Google
                </Link>
              </GridItem>
              <GridItem w="100%">
                <Link
                  display={"flex"}
                  alignItems={"center"}
                  justifyContent={"center"}
                  rounded="md"
                  bg="white"
                  fontSize={14}
                  border={1}
                  borderStyle="solid"
                  borderColor="gray.200"
                  padding={"10px 20px"}
                  borderRadius={6}
                  _hover={{
                    textDecoration: "none",
                    color: "blue.400",
                    bgColor: "gray.200",
                  }}
                >
                  <Image
                    src={fb}
                    w={15}
                    h={15}
                    me={2}
                  />
                  Sign in with Facebook
                </Link>
              </GridItem>
            </Grid>
            
            <FormControl m={"20px 0"}>
            <FormHelperText textAlign={"center"} mb={"20px"}>
            Or with email
              </FormHelperText>
              
              <Input type="email" placeholder="Email" mb={"20px"} />
              
              <Input type="password" placeholder="Password" />
             
              <Link
                  color={"blue.500"} display={"block"} textAlign="right" mb="40px"
                  fontWeight={500} mt="8px"
                  _hover={{
                    textDecoration: "none", color:"blue.700"
                  }}
                >
                  Forgot Password?
                </Link>
              
              <Button
                bgColor={"gray.900"}
                padding="15px 20px"
                height={"auto"}
                display={"block"}
                width={"100%"}
                color={"gray.200"}
                borderRadius={6}
                mb={"30px"}
                _hover={{
                  textDecoration: "none",
                  color: "gray.50",bgColor:"blue.500"
                }}
              >
                Sign In
              </Button>
              <Text fontSize="14px"  mb={"20px"} >
              Not a Member yet? 
                <Link
                  color={"blue.500"}
                  fontWeight={500}
                 ms={2}
                >
                  Sign Up
                </Link>
              </Text>
              <List display="flex" justifyContent="center">
                <ListItem>
                  <Link
                    color={"blue.500"}
                    fontWeight={500}
                    me={5}
                   
                  >
                    Terms
                  </Link>
                </ListItem>
                <ListItem>
                  <Link
                    color={"blue.500"}
                    fontWeight={500}
                    me={5}
                   
                  >
                    Plans
                  </Link>
                </ListItem>
                <ListItem>
                  <Link
                    color={"blue.500"}
                    fontWeight={500}
                   
                  >
                    Contact Us
                  </Link>
                </ListItem>
              </List>
            </FormControl>
          </Container>
        </Box>
        <Box display={"flex"} alignItems="center"
          textAlign="center"
          backgroundImage={Login_bg}
          backgroundPosition="top center"
          backgroundRepeat="no-repeat"
          height={"100vh"}
        >
          <Container>
            <Image src={logo} maxW="110px" m={"auto"}  mb={"50px"}/>
            <Image w={500} src={screen} mb={"60px"}/>
            <Heading fontSize="26" color={"white"} mb={"20px"}>
              Fast, Efficient and Productive
            </Heading>
            <Text fontSize="16" color={"white"}>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the 1500s, when an unknown printer
              took a galley of type and scrambled it to make a type specimen
              book.
            </Text>
          </Container>
        </Box>
      </SimpleGrid>
    </div>
  );
}

export default Login;
