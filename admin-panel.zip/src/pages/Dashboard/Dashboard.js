import React from "react";
import { GridItem, Grid, SimpleGrid, Box } from "@chakra-ui/react";
import Sidebar from "../../components/Sidebar/Sidebar";
import Performance from "../../components/Performance/Performance";
import Featured from "../../components/Featured/Featured";
import Achievment from "../../components/Achievement/Achievment";
import Overview from "../../components/Overview/Overview";
import ExternalLinks from "../../components/ExternalLinks/ExternalLinks";
import Professionals from "../../components/Professionals/Professionals";
import ActiveProject from "../../components/ActiveProject/ActiveProject";
import ProjectEarning from "../../components/ProjectEarning/ProjectEarning";
import Header from "../../components/Header/Header";
import Warephase from "../../components/Warephase/Warephase";
import HResource from "../../components/HResource/HResource";
import ProjectStats from "../../components/ProjectStats/ProjectStats";
const Dashboard = () => {
  return (
    <div>
      <Grid gridTemplateColumns={"300px 1fr"}>
        <GridItem>
          <Sidebar />
        </GridItem>
        <GridItem bgColor="gray.50">
        
          <Header />
         

          <Box px={9}>
            <SimpleGrid columns={4} spacing={6}>
              <ActiveProject />
              <ProjectEarning />
              <ExternalLinks />
              <Professionals />
              
            </SimpleGrid>

            <SimpleGrid columns={2} spacing={6}>
              <Overview />
              <Achievment />
            </SimpleGrid>

            <SimpleGrid columns={2} spacing={6}>
              <Featured />
              <Performance />
            </SimpleGrid>
            <SimpleGrid>
              
              <ProjectStats />
            </SimpleGrid>
            <SimpleGrid columns={2} spacing={6}>
              <Warephase />
              <HResource />
            </SimpleGrid>

          </Box>
        </GridItem>
      </Grid>
    </div>
  );
};

export default Dashboard;
