import React from "react";
import {
  GridItem,
  Grid,Box
} from "@chakra-ui/react";
import Sidebar from "../../components/Sidebar/Sidebar";
import Header from "../../components/Header/Header";
import MyProfile from '../../components/MyProfile/MyProfile';

function Profile() {
  return (
    <div>
         <Grid gridTemplateColumns={"300px 1fr"}>
        <GridItem>
          <Sidebar />
        </GridItem>
        <GridItem bgColor="gray.50">
          <Header />
        
      <Box px={9}>
        <MyProfile/>
      </Box>
      </GridItem>
      </Grid>
    </div>
  )
}

export default Profile