import {
  SearchIcon,
  HamburgerIcon,
  ChatIcon,
  InfoIcon,
  PlusSquareIcon,
  SettingsIcon,
  UnlockIcon,
  WarningIcon,
} from "@chakra-ui/icons";

export const sidebarData = [
  {
    menu: "Dashboard",
    icon: <HamburgerIcon position="absolute" left="-6" top="1" />,
    submenu: [
      "Default",
      "eCommerce",
      "Projects",
      "Online Courses",
      "Marketing",
    ],
  },
  {
    menu: "User Profile",
    submenu: ["Account", "Overview", "Settings", "Secutiry", "Activity"],
    icon: <SearchIcon position="absolute" left="-6" top="1" />,
  },

  {
    menu: "User Profile",
    submenu: ["Overview", "Projects", "Campaigns", "Followers", "Activity"],
    icon: <ChatIcon position="absolute" left="-6" top="1" />,
  },

  {
    menu: "Authentication",
    submenu: ["Overview", "Projects", "Campaigns", "Followers", "Activity"],
    icon: <InfoIcon position="absolute" left="-6" top="1" />,
  },

  {
    menu: "Authentication",
    submenu: ["Overview", "Projects", "Campaigns", "Followers", "Activity"],
    icon: <PlusSquareIcon position="absolute" left="-6" top="1" />,
  },

  {
    menu: "Authentication",
    submenu: ["Overview", "Projects", "Campaigns", "Followers", "Activity"],
    icon: <SettingsIcon position="absolute" left="-6" top="1" />,
  },

  {
    menu: "Authentication",
    submenu: ["Overview", "Projects", "Campaigns", "Followers", "Activity"],
    icon: <UnlockIcon position="absolute" left="-6" top="1" />,
  },

  {
    menu: "Authentication",
    submenu: ["Overview", "Projects", "Campaigns", "Followers", "Activity"],
    icon: <SearchIcon position="absolute" left="-6" top="1" />,
  },

  {
    menu: "Authentication",
    submenu: ["Overview", "Projects", "Campaigns", "Followers", "Activity"],
    icon: <WarningIcon position="absolute" left="-6" top="1" />,
  },
];
