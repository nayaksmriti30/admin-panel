import React from 'react';  
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import {} from "@chakra-ui/react";
import Dashboard from "./pages/Dashboard/Dashboard";
import DataTable from "./pages/Dashboard/DataTable";
import Profile from "./pages/Dashboard/Profile";
import ProfileEdit from './components/ProfileEdit/ProfileEdit';
import SignUp from './pages/Dashboard/SignUp';
import Login from './pages/Dashboard/Login';
import ForgotPassword from './pages/Dashboard/ForgotPassword';


function App() {
  return (
    <>
       <BrowserRouter>
        <Routes>
        <Route path="/" element={<Dashboard />} />  
        <Route path="DataTable" element={<DataTable />} />  
        <Route path="Profile" element={<Profile />} />  
        <Route path="ProfileEdit" element={<ProfileEdit />} />
        <Route path="SignUp" element={<SignUp />} />
        <Route path="Login" element={<Login />} />
        <Route path="ForgotPassword" element={<ForgotPassword />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
